# initial testing of the package creation

def hello():
    print("Hello stick slip!")
