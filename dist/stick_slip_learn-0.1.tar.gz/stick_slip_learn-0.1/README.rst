stick_slip_learn
--------------------

To use this package, simply run:
  >> ...
